﻿
namespace App
{
    partial class New
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label cod_estLabel;
            System.Windows.Forms.Label nombre_estLabel;
            System.Windows.Forms.Label apellido_estLabel;
            System.Windows.Forms.Label género_estLabel;
            System.Windows.Forms.Label número_estLabel;
            System.Windows.Forms.Label correo_estLabel;
            System.Windows.Forms.Label área_estLabel;
            System.Windows.Forms.Label nacionalidad_estLabel;
            System.Windows.Forms.Label fecha_estLabel;
            System.Windows.Forms.Label edad_estLabel;
            System.Windows.Forms.Label dirección_estLabel;
            System.Windows.Forms.Label tipodesangre_estLabel;
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.database1DataSet1 = new App.Database1DataSet1();
            this.estudianteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.estudianteTableAdapter = new App.Database1DataSet1TableAdapters.EstudianteTableAdapter();
            this.tableAdapterManager = new App.Database1DataSet1TableAdapters.TableAdapterManager();
            this.cod_estTextBox = new System.Windows.Forms.TextBox();
            this.nombre_estTextBox = new System.Windows.Forms.TextBox();
            this.apellido_estTextBox = new System.Windows.Forms.TextBox();
            this.género_estTextBox = new System.Windows.Forms.TextBox();
            this.número_estTextBox = new System.Windows.Forms.TextBox();
            this.correo_estTextBox = new System.Windows.Forms.TextBox();
            this.área_estTextBox = new System.Windows.Forms.TextBox();
            this.nacionalidad_estTextBox = new System.Windows.Forms.TextBox();
            this.fecha_estDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.edad_estTextBox = new System.Windows.Forms.TextBox();
            this.dirección_estTextBox = new System.Windows.Forms.TextBox();
            this.tipodesangre_estTextBox = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            cod_estLabel = new System.Windows.Forms.Label();
            nombre_estLabel = new System.Windows.Forms.Label();
            apellido_estLabel = new System.Windows.Forms.Label();
            género_estLabel = new System.Windows.Forms.Label();
            número_estLabel = new System.Windows.Forms.Label();
            correo_estLabel = new System.Windows.Forms.Label();
            área_estLabel = new System.Windows.Forms.Label();
            nacionalidad_estLabel = new System.Windows.Forms.Label();
            fecha_estLabel = new System.Windows.Forms.Label();
            edad_estLabel = new System.Windows.Forms.Label();
            dirección_estLabel = new System.Windows.Forms.Label();
            tipodesangre_estLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.estudianteBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(511, 231);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(107, 31);
            this.button2.TabIndex = 51;
            this.button2.Text = "Cancelar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(353, 231);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(97, 31);
            this.button1.TabIndex = 50;
            this.button1.Text = "Añadir";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // database1DataSet1
            // 
            this.database1DataSet1.DataSetName = "Database1DataSet1";
            this.database1DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // estudianteBindingSource
            // 
            this.estudianteBindingSource.DataMember = "Estudiante";
            this.estudianteBindingSource.DataSource = this.database1DataSet1;
            // 
            // estudianteTableAdapter
            // 
            this.estudianteTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CursoTableAdapter = null;
            this.tableAdapterManager.EstudianteTableAdapter = this.estudianteTableAdapter;
            this.tableAdapterManager.PadreTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = App.Database1DataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // cod_estLabel
            // 
            cod_estLabel.AutoSize = true;
            cod_estLabel.Location = new System.Drawing.Point(60, 20);
            cod_estLabel.Name = "cod_estLabel";
            cod_estLabel.Size = new System.Drawing.Size(21, 17);
            cod_estLabel.TabIndex = 51;
            cod_estLabel.Text = "ID";
            // 
            // cod_estTextBox
            // 
            this.cod_estTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estudianteBindingSource, "cod_est", true));
            this.cod_estTextBox.Location = new System.Drawing.Point(184, 17);
            this.cod_estTextBox.Name = "cod_estTextBox";
            this.cod_estTextBox.Size = new System.Drawing.Size(200, 22);
            this.cod_estTextBox.TabIndex = 52;
            // 
            // nombre_estLabel
            // 
            nombre_estLabel.AutoSize = true;
            nombre_estLabel.Location = new System.Drawing.Point(60, 48);
            nombre_estLabel.Name = "nombre_estLabel";
            nombre_estLabel.Size = new System.Drawing.Size(58, 17);
            nombre_estLabel.TabIndex = 53;
            nombre_estLabel.Text = "Nombre";
            // 
            // nombre_estTextBox
            // 
            this.nombre_estTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estudianteBindingSource, "nombre_est", true));
            this.nombre_estTextBox.Location = new System.Drawing.Point(184, 45);
            this.nombre_estTextBox.Name = "nombre_estTextBox";
            this.nombre_estTextBox.Size = new System.Drawing.Size(200, 22);
            this.nombre_estTextBox.TabIndex = 54;
            // 
            // apellido_estLabel
            // 
            apellido_estLabel.AutoSize = true;
            apellido_estLabel.Location = new System.Drawing.Point(60, 76);
            apellido_estLabel.Name = "apellido_estLabel";
            apellido_estLabel.Size = new System.Drawing.Size(58, 17);
            apellido_estLabel.TabIndex = 55;
            apellido_estLabel.Text = "Apellido";
            // 
            // apellido_estTextBox
            // 
            this.apellido_estTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estudianteBindingSource, "apellido_est", true));
            this.apellido_estTextBox.Location = new System.Drawing.Point(184, 73);
            this.apellido_estTextBox.Name = "apellido_estTextBox";
            this.apellido_estTextBox.Size = new System.Drawing.Size(200, 22);
            this.apellido_estTextBox.TabIndex = 56;
            // 
            // género_estLabel
            // 
            género_estLabel.AutoSize = true;
            género_estLabel.Location = new System.Drawing.Point(60, 104);
            género_estLabel.Name = "género_estLabel";
            género_estLabel.Size = new System.Drawing.Size(56, 17);
            género_estLabel.TabIndex = 57;
            género_estLabel.Text = "Género";
            // 
            // género_estTextBox
            // 
            this.género_estTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estudianteBindingSource, "género_est", true));
            this.género_estTextBox.Location = new System.Drawing.Point(184, 101);
            this.género_estTextBox.Name = "género_estTextBox";
            this.género_estTextBox.Size = new System.Drawing.Size(200, 22);
            this.género_estTextBox.TabIndex = 58;
            // 
            // número_estLabel
            // 
            número_estLabel.AutoSize = true;
            número_estLabel.Location = new System.Drawing.Point(60, 132);
            número_estLabel.Name = "número_estLabel";
            número_estLabel.Size = new System.Drawing.Size(58, 17);
            número_estLabel.TabIndex = 59;
            número_estLabel.Text = "Número";
            // 
            // número_estTextBox
            // 
            this.número_estTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estudianteBindingSource, "número_est", true));
            this.número_estTextBox.Location = new System.Drawing.Point(184, 129);
            this.número_estTextBox.Name = "número_estTextBox";
            this.número_estTextBox.Size = new System.Drawing.Size(200, 22);
            this.número_estTextBox.TabIndex = 60;
            // 
            // correo_estLabel
            // 
            correo_estLabel.AutoSize = true;
            correo_estLabel.Location = new System.Drawing.Point(60, 160);
            correo_estLabel.Name = "correo_estLabel";
            correo_estLabel.Size = new System.Drawing.Size(51, 17);
            correo_estLabel.TabIndex = 61;
            correo_estLabel.Text = "Correo";
            // 
            // correo_estTextBox
            // 
            this.correo_estTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estudianteBindingSource, "correo_est", true));
            this.correo_estTextBox.Location = new System.Drawing.Point(184, 157);
            this.correo_estTextBox.Name = "correo_estTextBox";
            this.correo_estTextBox.Size = new System.Drawing.Size(200, 22);
            this.correo_estTextBox.TabIndex = 62;
            // 
            // área_estLabel
            // 
            área_estLabel.AutoSize = true;
            área_estLabel.Location = new System.Drawing.Point(412, 17);
            área_estLabel.Name = "área_estLabel";
            área_estLabel.Size = new System.Drawing.Size(38, 17);
            área_estLabel.TabIndex = 63;
            área_estLabel.Text = "Área";
            // 
            // área_estTextBox
            // 
            this.área_estTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estudianteBindingSource, "área_est", true));
            this.área_estTextBox.Location = new System.Drawing.Point(536, 14);
            this.área_estTextBox.Name = "área_estTextBox";
            this.área_estTextBox.Size = new System.Drawing.Size(200, 22);
            this.área_estTextBox.TabIndex = 64;
            // 
            // nacionalidad_estLabel
            // 
            nacionalidad_estLabel.AutoSize = true;
            nacionalidad_estLabel.Location = new System.Drawing.Point(412, 45);
            nacionalidad_estLabel.Name = "nacionalidad_estLabel";
            nacionalidad_estLabel.Size = new System.Drawing.Size(90, 17);
            nacionalidad_estLabel.TabIndex = 65;
            nacionalidad_estLabel.Text = "Nacionalidad";
            // 
            // nacionalidad_estTextBox
            // 
            this.nacionalidad_estTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estudianteBindingSource, "nacionalidad_est", true));
            this.nacionalidad_estTextBox.Location = new System.Drawing.Point(536, 42);
            this.nacionalidad_estTextBox.Name = "nacionalidad_estTextBox";
            this.nacionalidad_estTextBox.Size = new System.Drawing.Size(200, 22);
            this.nacionalidad_estTextBox.TabIndex = 66;
            // 
            // fecha_estLabel
            // 
            fecha_estLabel.AutoSize = true;
            fecha_estLabel.Location = new System.Drawing.Point(412, 74);
            fecha_estLabel.Name = "fecha_estLabel";
            fecha_estLabel.Size = new System.Drawing.Size(139, 17);
            fecha_estLabel.TabIndex = 67;
            fecha_estLabel.Text = "Fecha de nacimiento";
            // 
            // fecha_estDateTimePicker
            // 
            this.fecha_estDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.estudianteBindingSource, "fecha_est", true));
            this.fecha_estDateTimePicker.Location = new System.Drawing.Point(536, 70);
            this.fecha_estDateTimePicker.Name = "fecha_estDateTimePicker";
            this.fecha_estDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.fecha_estDateTimePicker.TabIndex = 68;
            // 
            // edad_estLabel
            // 
            edad_estLabel.AutoSize = true;
            edad_estLabel.Location = new System.Drawing.Point(412, 101);
            edad_estLabel.Name = "edad_estLabel";
            edad_estLabel.Size = new System.Drawing.Size(41, 17);
            edad_estLabel.TabIndex = 69;
            edad_estLabel.Text = "Edad";
            // 
            // edad_estTextBox
            // 
            this.edad_estTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estudianteBindingSource, "edad_est", true));
            this.edad_estTextBox.Location = new System.Drawing.Point(536, 98);
            this.edad_estTextBox.Name = "edad_estTextBox";
            this.edad_estTextBox.Size = new System.Drawing.Size(200, 22);
            this.edad_estTextBox.TabIndex = 70;
            // 
            // dirección_estLabel
            // 
            dirección_estLabel.AutoSize = true;
            dirección_estLabel.Location = new System.Drawing.Point(412, 129);
            dirección_estLabel.Name = "dirección_estLabel";
            dirección_estLabel.Size = new System.Drawing.Size(67, 17);
            dirección_estLabel.TabIndex = 71;
            dirección_estLabel.Text = "Dirección";
            // 
            // dirección_estTextBox
            // 
            this.dirección_estTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estudianteBindingSource, "dirección_est", true));
            this.dirección_estTextBox.Location = new System.Drawing.Point(536, 126);
            this.dirección_estTextBox.Name = "dirección_estTextBox";
            this.dirección_estTextBox.Size = new System.Drawing.Size(200, 22);
            this.dirección_estTextBox.TabIndex = 72;
            // 
            // tipodesangre_estLabel
            // 
            tipodesangre_estLabel.AutoSize = true;
            tipodesangre_estLabel.Location = new System.Drawing.Point(412, 157);
            tipodesangre_estLabel.Name = "tipodesangre_estLabel";
            tipodesangre_estLabel.Size = new System.Drawing.Size(104, 17);
            tipodesangre_estLabel.TabIndex = 73;
            tipodesangre_estLabel.Text = "Tipo de sangre";
            // 
            // tipodesangre_estTextBox
            // 
            this.tipodesangre_estTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estudianteBindingSource, "tipodesangre_est", true));
            this.tipodesangre_estTextBox.Location = new System.Drawing.Point(536, 154);
            this.tipodesangre_estTextBox.Name = "tipodesangre_estTextBox";
            this.tipodesangre_estTextBox.Size = new System.Drawing.Size(200, 22);
            this.tipodesangre_estTextBox.TabIndex = 74;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(184, 231);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(97, 31);
            this.button3.TabIndex = 75;
            this.button3.Text = "Guardar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // New
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(cod_estLabel);
            this.Controls.Add(this.cod_estTextBox);
            this.Controls.Add(nombre_estLabel);
            this.Controls.Add(this.nombre_estTextBox);
            this.Controls.Add(apellido_estLabel);
            this.Controls.Add(this.apellido_estTextBox);
            this.Controls.Add(género_estLabel);
            this.Controls.Add(this.género_estTextBox);
            this.Controls.Add(número_estLabel);
            this.Controls.Add(this.número_estTextBox);
            this.Controls.Add(correo_estLabel);
            this.Controls.Add(this.correo_estTextBox);
            this.Controls.Add(área_estLabel);
            this.Controls.Add(this.área_estTextBox);
            this.Controls.Add(nacionalidad_estLabel);
            this.Controls.Add(this.nacionalidad_estTextBox);
            this.Controls.Add(fecha_estLabel);
            this.Controls.Add(this.fecha_estDateTimePicker);
            this.Controls.Add(edad_estLabel);
            this.Controls.Add(this.edad_estTextBox);
            this.Controls.Add(dirección_estLabel);
            this.Controls.Add(this.dirección_estTextBox);
            this.Controls.Add(tipodesangre_estLabel);
            this.Controls.Add(this.tipodesangre_estTextBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "New";
            this.Text = "Agregar nuevo registro";
            this.Load += new System.EventHandler(this.New_Load);
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.estudianteBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private Database1DataSet1 database1DataSet1;
        private System.Windows.Forms.BindingSource estudianteBindingSource;
        private Database1DataSet1TableAdapters.EstudianteTableAdapter estudianteTableAdapter;
        private Database1DataSet1TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox cod_estTextBox;
        private System.Windows.Forms.TextBox nombre_estTextBox;
        private System.Windows.Forms.TextBox apellido_estTextBox;
        private System.Windows.Forms.TextBox género_estTextBox;
        private System.Windows.Forms.TextBox número_estTextBox;
        private System.Windows.Forms.TextBox correo_estTextBox;
        private System.Windows.Forms.TextBox área_estTextBox;
        private System.Windows.Forms.TextBox nacionalidad_estTextBox;
        private System.Windows.Forms.DateTimePicker fecha_estDateTimePicker;
        private System.Windows.Forms.TextBox edad_estTextBox;
        private System.Windows.Forms.TextBox dirección_estTextBox;
        private System.Windows.Forms.TextBox tipodesangre_estTextBox;
        private System.Windows.Forms.Button button3;
    }
}