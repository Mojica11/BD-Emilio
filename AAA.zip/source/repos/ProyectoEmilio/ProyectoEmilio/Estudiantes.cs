﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoEmilio
{
    public partial class Estudiantes : Form
    {

        public Estudiantes()
        {
            InitializeComponent();
        }
         private static void Main() { }
       
        private void estudianteBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.estudianteBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.database1DataSet1);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'database1DataSet1.Padre' Puede moverla o quitarla según sea necesario.
            this.padreTableAdapter.Fill(this.database1DataSet1.Padre);
            // TODO: esta línea de código carga datos en la tabla 'database1DataSet1.Curso' Puede moverla o quitarla según sea necesario.
            this.cursoTableAdapter.Fill(this.database1DataSet1.Curso);
            // TODO: esta línea de código carga datos en la tabla 'database1DataSet1.Estudiante' Puede moverla o quitarla según sea necesario.
            this.estudianteTableAdapter.Fill(this.database1DataSet1.Estudiante);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void estudianteDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form formulario = new Form1();
            formulario.Show();
        }
    }
}


